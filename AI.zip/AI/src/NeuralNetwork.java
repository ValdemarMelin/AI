import java.util.Scanner;

import javax.swing.JFrame;

public class NeuralNetwork {
	
	
	private double[/*layer*/][/*neuron*/][/*parameter*/] k;
	double[/*layer*/][/*neuron*/] output;
	double[] input;
	private double[] [][] jacobian;
	
	public NeuralNetwork(int... layers) {
		k = new double[layers.length-1][][];
		for(int i = 0; i < k.length; i++) {
			k[i] = new double[layers[i+1]][]; // number of neurons
			for(int j = 0; j < k[i].length; j++) {
				k[i][j] = new double[layers[i]+1]; // number of coefficients + bias
				k[i][j][0] = Math.random() - 0.5; // Bias
				for(int l = 1; l < k[i][j].length; l++) {
					k[i][j][l] = Math.random() - 0.5;
				}
			}
		}
		
		output = new double[layers.length-1][];
		for(int i = 0; i < output.length; i++) {
			output[i] = new double[layers[i+1]];
		}
		
		input = new double[layers[0]];
	}
	
	public void propagate() {
		for(int j = 0; j < k[0].length; j++) {
			double sum = k[0][j][0];
			for(int l = 1; l < k[0][j].length; l++) {
				sum += k[0][j][l]*input[l-1];
			}
			this.output[0][j] = f(sum);
		}
		for(int i = 1; i < k.length; i++) {
			for(int j = 0; j < k[i].length; j++) {
				double sum = k[i][j][0];
				for(int l = 1; l < k[i][j].length; l++) {
					sum += k[i][j][l]*this.output[i-1][l-1];
				}
				this.output[i][j] = f(sum);
			}
		}
	}
	
	public int getLayerCount() {
		return k.length;
	}
	
	public int getLayerSize(int layer) {
		return k[layer].length;
	}
	
	private final double f(double x) {
		return 1 / (1 + Math.exp(-x));
	}
	
	@SuppressWarnings("unused")
	private final double df_dx(double x) {
		double fx = f(x);
		return fx*(1-fx);
	}
	
	public String getStructure() {
		String s = "Neural network, " + this.k.length + " layers." + System.lineSeparator();
		for(int i = 0; i < this.k.length; i++) {
			s += "    Layer " + (i+1) + ": " + this.k[i].length + " neurons." + System.lineSeparator();
			for(int j = 0; j < this.k[i].length; j++) {
				s += "        Neuron " + j + ": [bias: " + k[i][j][0] + ",";
				for(int l = 1; l < this.k[i][j].length; l++) {
					s += " a" + l + ": " + k[i][j][l];
				}
				s += "]" + System.lineSeparator();
			}
		}
		return s;
	}
	
	public static void main(String[] args) {
		NeuralNetwork net = new NeuralNetwork(3, 7, 11, 20, 2);
		Scanner scan = new Scanner(System.in);
		loop:while(true) {
			String line = scan.nextLine();
			String cmd = line.split(" ")[0];
			switch(cmd.trim().toLowerCase()) {
			case "exit":
				break loop;
			case "display":
			{
				JFrame frame = new JFrame("Test");
				frame.setSize(800, 600);
				frame.setLocationRelativeTo(null);
				frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				frame.add(new NeuralNetworkView(net));
				frame.setVisible(true);
			}
				break;
			case "input": {
				String[] words = line.split(" ");
				for(int i = 0; i < net.input.length; i++) {
					double m = Double.parseDouble(words[i+1].trim());
					net.input[i] = m;
				}}
				break;
			case "help":
				System.out.println("Type exit for exit");
				System.out.println("Commands:");
				System.out.println("display: creates a window showing the network");
				System.out.println("input n1 n2 ... nN: sets the input of the network");
				System.out.println("propagate: propagates the input through the network");
				System.out.println("output: prints output of network");
				System.out.println("structure: prints structure of the network, with weights etc");
				System.out.println("weight l n i: prints the weight of layer l, neuron n, weight i");
				System.out.println("bias l n: prints the bias of layer l, neuron n");
				System.out.println();
				break;
			case "propagate":
				net.propagate();
				break;
			case "weight": {
				String[] words = line.split(" ");
				int l = Integer.parseInt(words[1]);
				int n = Integer.parseInt(words[2]);
				int i = Integer.parseInt(words[3]);
				System.out.println(net.k[l][n][i+1]);
			}
				break;
			case "bias": {
				String[] words = line.split(" ");
				int l = Integer.parseInt(words[1]);
				int n = Integer.parseInt(words[2]);
				System.out.println(net.k[l][n][0]);
			}
				break;
			case "structure":
				System.out.println(net.getStructure());
				break;
			case "output":
					for(int i = 0; i < net.output[net.output.length-1].length; i++) {
						System.out.print(net.output[net.output.length-1][i] + " ");
					}
					System.out.println();
					break;
			default:
				System.out.println("Unknown command. Try \"help\" for help.");
				break;
			}
		}
		System.exit(0);
	}

	public int getInputLayerSize() {
		return k[0][0].length - 1; // Number of weights minus bias
	}
}
